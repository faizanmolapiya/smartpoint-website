SMARTPOINT — 5-PAGE STATIC WEBSITE
================================
Pages: index.html, about.html, products.html, privacy-policy.html, contact.html

Contact phone: +91 9510013940
Email entered exactly as provided: Dmfaizan@44gmail.com
IMPORTANT: Verify the email spelling before publishing.

GET WEBSITE LIVE — CLOUDFLARE PAGES
1. Go to Cloudflare Dashboard > Workers & Pages > Create > Pages.
2. Choose Upload assets / Direct Upload.
3. Upload the included ZIP or folder contents (index.html must be at root).
4. Deploy and open the provided *.pages.dev URL.

GET WEBSITE LIVE — GITHUB PAGES
1. Create a public GitHub repository.
2. Extract the ZIP, and upload the included website files and assets folder to repository root.
3. Settings > Pages > Deploy from a branch > main > /(root) > Save.
4. Wait for publishing and open your github.io link.

FEATURES
- Responsive five-page layout based on supplied visual inspiration.
- Client-provided SMARTPOINT logo processed from original upload.
- 12 illustrative demo products, with browser-based category filtering and search.
- Add-to-enquiry basket (localStorage); WhatsApp enquiry composition.
- Contact and newsletter forms use mailto links; no database or backend.

BEFORE SHARING WITH CLIENT
- Change demonstration images, products, prices, ratings and discounts to actual values.
- Add physical address / business details if needed.
- Confirm contact email spelling.
- Customize privacy policy to true business practices.
- No automatic payment, cart checkout, user accounts or online order system.

Note: Product graphics are original illustrative SVG mockups, not official manufacturer photos.
